package com.example.BookstoreAPI.controller;

import com.example.BookstoreAPI.entity.Book;
import com.example.BookstoreAPI.exception.BookNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/books")
public class BookController {

    private Map<Long, Book> books = new HashMap<>();

    // POST endpoint to create a new book with custom headers
    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        books.put(book.getId(), book);

        // Custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Created Successfully");

        return new ResponseEntity<>(book, headers, HttpStatus.CREATED);
    }

    // GET endpoint to fetch a book by ID with custom headers
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = books.get(id);
        if (book == null) {
            throw new BookNotFoundException("Book with ID " + id + " not found");
        }
        return ResponseEntity.ok(book);
    }

    // PUT endpoint to update a book with custom headers
    @PutMapping("/{id}")
    public ResponseEntity<Void> updateBook(@PathVariable Long id, @RequestBody Book book) {
        books.put(id, book);

        // Custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Updated Successfully");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }

    // DELETE endpoint to delete a book with custom headers
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        books.remove(id);

        // Custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Deleted Successfully");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}
