package com.example.bookstoreapi.mapper;

//package com.example.bookstoreapi.service.impl;

import com.example.bookstoreapi.dto.CustomerDTO;
import com.example.bookstoreapi.model.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper
public interface CustomerMapper {
    CustomerDTO toDTO(Customer customer);
    Customer toEntity(CustomerDTO customerDTO);
    void updateCustomerFromDto(CustomerDTO customerDTO, @MappingTarget Customer customer);
}
