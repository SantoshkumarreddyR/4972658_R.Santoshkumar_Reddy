package com.example.bookstoreapi.dto;

public @interface XmlRootElement {

}
